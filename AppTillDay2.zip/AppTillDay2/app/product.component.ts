
import {Component,Input} from '@angular/core'


@Component({
selector:`product`,
template:`

<div class="Product">
<h2> {{prodDetails.name }} </h2>
<img [src]="prodDetails.ImageUrl" height="200px" width="200px"  /> <br/>
                <b> Price :  </b> {{prodDetails.price }} <br/>
                <b> Quantity :  </b> {{prodDetails.quantity}} <br/>
                <b> Rating :  </b> {{prodDetails.rating }} <br/>
               
    </div> 
`
})
export class ProductComponent{
     @Input()   prodDetails={};
}