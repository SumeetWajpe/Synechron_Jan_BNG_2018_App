
import {Component,Input} from '@angular/core'
import {PostsService} from './posts.service'

@Component({
selector:`post`,
template:`<h1> Posts </h1>
<ul>
    <li *ngFor="let post of receivedPosts">
    {{post.title}}
    </li>
</ul>
`,
providers:[PostsService]
})
export class PostComponent{
    receivedPosts:any[];
//     constructor(private postObj:PostsService){
// this.postObj.getPosts((theResponse:any)=>{
//                         this.receivedPosts = theResponse;
//                 }); // use of service !
// }


    constructor(private postObj:PostsService){
var aPromise = this.postObj.getPosts(); // use of service !
aPromise.then(
    (response)=>{
        this.receivedPosts = response.json();//converts to jsObject
        window.localStorage["posts"] = JSON.stringify(this.receivedPosts);
      },(err)=>{
        console.log(err);
      }); // eof promise.then()
}// eof constructor



}