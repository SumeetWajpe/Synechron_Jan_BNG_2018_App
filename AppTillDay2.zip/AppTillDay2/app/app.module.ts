import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {FormsModule} from '@angular/forms';
import {HttpModule} from'@angular/http';

import { AppComponent }  from './app.component';
import { CourseComponent } from './course.component';
import { ShoppingCartComponent } from './shoppingcart.component';
import { ProductComponent } from './product.component';
import { UseProductServiceComponent } from './useproductservice.component';
import { ProductService } from './product.service';
import { PostComponent } from './post.component';


@NgModule({
  imports:      [ BrowserModule,FormsModule,HttpModule ],
  declarations: [ AppComponent,CourseComponent,ShoppingCartComponent,ProductComponent ,UseProductServiceComponent,PostComponent],
  bootstrap:    [ AppComponent ],
  providers:[ProductService],

})
export class AppModule { }
