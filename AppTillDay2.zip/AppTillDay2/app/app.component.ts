import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  template:`
  <post></post>
  `
  // template:`<useproductserv></useproductserv>
  // <useproductserv></useproductserv>`
  // template:`
  // <shoppingcart></shoppingcart>
  // `
  // template:`  
  // <div  *ngFor="let c of courses">
  // <course [coursedetails]="c" ></course>
  // </div>  
  // `
  // template: `<h1>Hello {{name}}</h1>  
  // <img src={{imageUrl}} />
  // <img [src]="imageUrl" />   
  // `,
})
export class AppComponent  { 
  name = 'Angular 5.0'; 
  courses =[ {name:'ReactJS',price:4000},
  {name:'NodeJS',price:3000},
  {name:'Backbone',price:5000}
];
  
  imageUrl:string = 'https://www.vectorlogo.zone/logos/angular/angular-card.png'
}
